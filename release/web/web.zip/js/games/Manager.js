var game = null;

const LEFT = 37;
const UP = 38;
const RIGHT = 39;
const DOWN = 40;
const DELT = 5;