export default class GlobalConfig extends Laya.Script {

    constructor() { 
        super(); 
    }
    
    onEnable() {
    }

    onDisable() {
    }
}

GlobalConfig.wsHost = "129.28.190.44";
GlobalConfig.wsPort = 1212;